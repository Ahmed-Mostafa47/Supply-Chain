/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.supplychainn;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "product")
@NamedQueries({
    @NamedQuery(name = "Product.findAll", query = "SELECT p FROM Product p"),
    @NamedQuery(name = "Product.findById", query = "SELECT p FROM Product p WHERE p.id = :id"),
    @NamedQuery(name = "Product.findByProductName", query = "SELECT p FROM Product p WHERE p.productName = :productName"),
    @NamedQuery(name = "Product.findByUnitPrice", query = "SELECT p FROM Product p WHERE p.unitPrice = :unitPrice"),
    @NamedQuery(name = "Product.findByPackage1", query = "SELECT p FROM Product p WHERE p.package1 = :package1"),
    @NamedQuery(name = "Product.findByIsDiscontinued", query = "SELECT p FROM Product p WHERE p.isDiscontinued = :isDiscontinued")})
public class Product implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "Id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "ProductName")
    private String productName;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "UnitPrice")
    private BigDecimal unitPrice;
    @Column(name = "Package")
    private String package1;
    @Basic(optional = false)
    @Column(name = "IsDiscontinued")
    private boolean isDiscontinued;
    @JoinColumn(name = "SupplierId", referencedColumnName = "Id")
    @ManyToOne(optional = false)
    private Supplier supplierId;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "productId")
    private Collection<Orderitem> orderitemCollection;

    public Product() {
    }

    public Product(Integer id) {
        this.id = id;
    }

    public Product(Integer id, String productName, boolean isDiscontinued) {
        this.id = id;
        this.productName = productName;
        this.isDiscontinued = isDiscontinued;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public BigDecimal getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(BigDecimal unitPrice) {
        this.unitPrice = unitPrice;
    }

    public String getPackage1() {
        return package1;
    }

    public void setPackage1(String package1) {
        this.package1 = package1;
    }

    public boolean getIsDiscontinued() {
        return isDiscontinued;
    }

    public void setIsDiscontinued(boolean isDiscontinued) {
        this.isDiscontinued = isDiscontinued;
    }

    public Supplier getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(Supplier supplierId) {
        this.supplierId = supplierId;
    }

    public Collection<Orderitem> getOrderitemCollection() {
        return orderitemCollection;
    }

    public void setOrderitemCollection(Collection<Orderitem> orderitemCollection) {
        this.orderitemCollection = orderitemCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Product)) {
            return false;
        }
        Product other = (Product) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.supplychainn.Product[ id=" + id + " ]";
    }
    
    // Create
    public static void createProduct(EntityManager em, Integer id, String productName, BigDecimal unitPrice, 
            String package1, boolean isDiscontinued, int supplierId) {
        em.getTransaction().begin();
        Product product = new Product();
        product.setId(id);
        product.setProductName(productName);
        product.setUnitPrice(unitPrice);
        product.setPackage1(package1);
        product.setIsDiscontinued(isDiscontinued);
        
        Supplier supplier = em.find(Supplier.class, supplierId);
        if (supplier == null) {
            System.out.println("Supplier not found with ID: " + supplierId);
            em.getTransaction().rollback();
            return;
        }
        product.setSupplierId(supplier);
        
        em.persist(product);
        em.getTransaction().commit();
        System.out.println("Product with id "+id+" created successfully.");
    }

    // Read by ID
    public static Product getProductById(EntityManager em, int id) {
        return em.find(Product.class, id);
    }

    // Update
    public static void updateProduct(EntityManager em, int id, String newName, BigDecimal newPrice,
            String newPackage, boolean newIsDiscontinued, int newSupplierId) {
        em.getTransaction().begin();
        Product product = em.find(Product.class, id);
        if (product != null) {
            product.setProductName(newName);
            product.setUnitPrice(newPrice);
            product.setPackage1(newPackage);
            product.setIsDiscontinued(newIsDiscontinued);
            
            Supplier newSupplier = em.find(Supplier.class, newSupplierId);
            if (newSupplier != null) {
                product.setSupplierId(newSupplier);
            } else {
                System.out.println("New supplier not found with ID: " + newSupplierId);
                em.getTransaction().rollback();
                return;
            }

            em.merge(product);
            System.out.println("Product with "+id+" updated successfully.");
        } else {
            System.out.println("Product not found with ID: " + id);
        }
        em.getTransaction().commit();
    }

    // Delete
    public static void deleteProduct(EntityManager em, int id) {
        em.getTransaction().begin();
        Product product = em.find(Product.class, id);
        if (product != null) {
            em.remove(product);
            System.out.println("Product with "+id+" deleted successfully.");
        } else {
            System.out.println("Product not found with ID: " + id);
        }
        em.getTransaction().commit();
    }

    // Get All Products
    public static List<Product> getAllProducts(EntityManager em) {
        return em.createQuery("SELECT p FROM Product p", Product.class).getResultList();
    }
}
