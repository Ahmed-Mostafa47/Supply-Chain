
package com.mycompany.supplychainn;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.util.List;

public class ProductGUI extends JFrame {
    private JTextField idField, nameField, priceField, packageField, supplierIdField;
    private JCheckBox discontinuedBox;
    private JTable productTable;
    private DefaultTableModel tableModel;
    private EntityManagerFactory emf;

    public ProductGUI() {
        emf = Persistence.createEntityManagerFactory("com.mycompany_SupplyChainn_jar_1.0-SNAPSHOTPU");
        setTitle("Product Management");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 500);
        setLayout(new BorderLayout());

        // Top Panel for Form
        JPanel formPanel = new JPanel(new GridLayout(3, 4, 10, 10));
        idField = new JTextField();
        nameField = new JTextField();
        priceField = new JTextField();
        packageField = new JTextField();
        supplierIdField = new JTextField();
        discontinuedBox = new JCheckBox("Discontinued");
        formPanel.add(new JLabel("Product ID:"));
        formPanel.add(idField);
        formPanel.add(new JLabel("Product Name:"));
        formPanel.add(nameField);
        formPanel.add(new JLabel("Unit Price:"));
        formPanel.add(priceField);
        formPanel.add(new JLabel("Package:"));
        formPanel.add(packageField);
        formPanel.add(new JLabel("Supplier ID:"));
        formPanel.add(supplierIdField);
        formPanel.add(discontinuedBox);
        add(formPanel, BorderLayout.NORTH);

        tableModel = new DefaultTableModel(new String[]{"ID", "Name", "Price", "Package", "Discontinued", "SupplierID"}, 0);
        productTable = new JTable(tableModel);
        add(new JScrollPane(productTable), BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        JButton addBtn = new JButton("Add");
        JButton updateBtn = new JButton("Update");
        JButton deleteBtn = new JButton("Delete");
        JButton viewAllBtn = new JButton("View All"); 
        buttonPanel.add(addBtn);
        buttonPanel.add(updateBtn);
        buttonPanel.add(deleteBtn);
        buttonPanel.add(viewAllBtn); 
        add(buttonPanel, BorderLayout.SOUTH);

      
        addBtn.addActionListener(e -> addProduct());
        updateBtn.addActionListener(e -> updateProduct());
        deleteBtn.addActionListener(e -> deleteProduct());
        viewAllBtn.addActionListener(e -> loadAllProducts()); 

        loadProducts();
        setVisible(true);
    }

    private void addProduct() {
        EntityManager em = emf.createEntityManager();
        try {
            Integer id = Integer.parseInt(idField.getText());
            String name = nameField.getText();
            BigDecimal price = new BigDecimal(priceField.getText());
            String pack = packageField.getText();
            boolean isDiscontinued = discontinuedBox.isSelected();
            int supplierId = Integer.parseInt(supplierIdField.getText());
            Product.createProduct(em, id, name, price, pack, isDiscontinued, supplierId);
            loadProducts();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error adding product: " + ex.getMessage());
        } finally {
            em.close();
        }
    }

    private void updateProduct() {
        EntityManager em = emf.createEntityManager();
        try {
            int id = Integer.parseInt(idField.getText());
            String name = nameField.getText();
            BigDecimal price = new BigDecimal(priceField.getText());
            String pack = packageField.getText();
            boolean isDiscontinued = discontinuedBox.isSelected();
            int supplierId = Integer.parseInt(supplierIdField.getText());
            Product.updateProduct(em, id, name, price, pack, isDiscontinued, supplierId);
            loadProducts();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error updating product: " + ex.getMessage());
        } finally {
            em.close();
        }
    }

    private void deleteProduct() {
        EntityManager em = emf.createEntityManager();
        try {
            int id = Integer.parseInt(idField.getText());
            Product.deleteProduct(em, id);
            loadProducts();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error deleting product: " + ex.getMessage());
        } finally {
            em.close();
        }
    }

    private void loadProducts() {
        EntityManager em = emf.createEntityManager();
        try {
            List<Product> products = Product.getAllProducts(em);
            tableModel.setRowCount(0); // Clear table
            for (Product p : products) {
                tableModel.addRow(new Object[]{
                        p.getId(),
                        p.getProductName(),
                        p.getUnitPrice(),
                        p.getPackage1(),
                        p.getIsDiscontinued(),
                        p.getSupplierId().getId()
                });
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error loading products: " + ex.getMessage());
        } finally {
            em.close();
        }
    }

    // New method to load all products
    private void loadAllProducts() {
        EntityManager em = emf.createEntityManager();
        try {
            List<Product> products = Product.getAllProducts(em); // Retrieve all products
            tableModel.setRowCount(0); // Clear existing rows in the table
            for (Product p : products) {
                tableModel.addRow(new Object[]{
                        p.getId(),
                        p.getProductName(),
                        p.getUnitPrice(),
                        p.getPackage1(),
                        p.getIsDiscontinued(),
                        p.getSupplierId().getId()
                });
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error loading all products: " + ex.getMessage());
        } finally {
            em.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
      public static void main(String args[]) {
        /* Set the Nimbus look and feel */
  

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ProductGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify                     
    // End of variables declaration                   
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
