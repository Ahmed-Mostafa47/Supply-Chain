

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.supplychainn;

import java.math.BigDecimal;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author HP
 */
public class Main {

    public static void main(String[] args) {
    EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_SupplyChainn_jar_1.0-SNAPSHOTPU");
    EntityManager em = emf.createEntityManager();
        try {     
           
             java.awt.EventQueue.invokeLater(new Runnable() {
        @Override
        public void run() {
            new MainWindow().setVisible(true);
        }
    });
         // Test Create Customer   
//       Customer.createCustomer(em,  "Sara", "yonan", "Alex", "Egypt","01234673628");
//       Customer.createCustomer(em,  "Omar", "Nasser", "Cairo", "Egypt","01156745628");
       //Customer.createCustomer(em,  "Ahmed", "Mostafa", "chicago", "USA","01143069909");

        // Test Read all Customers
        List<Customer> Customerlist = Customer.getAllCustomers(em);
        System.out.println("All Customers:");
        for (Customer customer : Customerlist) {
            System.out.println("customer ID: " + customer.getId() + ", First Name: " + customer.getFirstName() + ", Last NAME: " + customer.getLastName());
        }

        // Test get customer by ID
        Customer customer = Customer.getCustomerById(em, 20);
        if (customer != null) {
            System.out.println("Fetched Customer: ID: " + customer.getId() + ", First Name: " + customer.getFirstName());
        }

        // Test update customer
        //Customer.updateCustomer(em, 22, "Farida", "Emad","sharqiya", "Egypt", "01101125645");

        // Test Delete customer
        //Customer.deleteCustomer(em, 22);  // Deleting customer with ID 22
        
//        Customer existingCustomer = Customer.getCustomerById(em, 1); // أو em.find(Customer.class, 1);
            
        //create order
        //Orders.createOrder(em, 8, "2025-05-01", "ORD008", new BigDecimal("499.99"), 11);
        //Delete order
        //Orders.deleteOrder(em, 8);
        //update order
        //Orders.updateOrder(em, 7, "2025-05-02", "ORD011", new BigDecimal("599.99"),12);
        //get all orders
        List<Orders> orders = Orders.getAllOrders(em);
            for (Orders o : orders) {
                System.out.println("Order ID: " + o.getId() +
                       ", Order Date: " + o.getOrderDate() +
                       ", Customer: " + o.getCustomerId().getFirstName() + " " + o.getCustomerId().getLastName());
                                    }
        //Get Order by Id
        int orderId = 7; 
        Orders order = Orders.getOrderById(em, orderId);

            if (order != null) {
                System.out.println("Order ID: " + order.getId());
                System.out.println("Order Date: " + order.getOrderDate());
                System.out.println("Customer: " + order.getCustomerId().getFirstName() + " " + order.getCustomerId().getLastName());
            } else {
                System.out.println("No order found with ID: " + orderId);
            }
        
              // ===== CREATE order item =====
        //Orderitem.createOrderItem(em, 110, new BigDecimal("99.99"), 2, 28, 2);

        // ===== READ order item by id =====
        Orderitem item = Orderitem.getOrderItemById(em, 109);
        if (item != null) {
            System.out.println("Read OrderItem: ID = " + item.getId() + ", Quantity = " + item.getQuantity());
        }

        // ===== UPDATE order item=====
       // Orderitem.updateOrderItem(em, 109, new BigDecimal("120.50"), 3, 21, 3);

        // ===== READ ALL =====
        List<Orderitem> allItems = Orderitem.getAllOrderItems(em);
        for (Orderitem oi : allItems) {
           System.out.println("OrderItem ID: " + oi.getId() + ", Quantity: " + oi.getQuantity());
        }

        // ===== DELETE =====
        //Orderitem.deleteOrderItem(em, 110);
//        
        // ------- Create Product -------
        //Product.createProduct(em, 29, "Mobile", new BigDecimal("7500.00"), "Box", false, 209);

        // ------- Read Product by ID -------
        Product p = Product.getProductById(em, 21);
        if (p != null) {
            System.out.println("Product Found: " + p.getProductName());
        } else {
            System.out.println("Product not found.");
        }

//        Product.updateProduct(em, 31, "Gaming Laptop", new BigDecimal("9500.00"), "Gaming Box", false, 202);

        // ------- Get All Products -------
        List<Product> allProducts = Product.getAllProducts(em);
        System.out.println("All Products:");
        for (Product prod : allProducts) {
            System.out.println("ID: " + prod.getId() + ", Name: " + prod.getProductName());
        }
        // ------- Update Product -------
        int productId = 27; 
        String newName = "Laptop";
        BigDecimal newPrice = new BigDecimal("99.99");
        String newPackage = "Box";
        boolean newIsDiscontinued = false;
        int newSupplierId = 208; 
        Product.updateProduct(em, productId, newName, newPrice, newPackage, newIsDiscontinued, newSupplierId);

        // ------- Delete Product -------
//        Product.deleteProduct(em, 29);
        
        //create Supplier
        //Supplier.createSupplier(em, 210, "Tech Supplies Ltd", "Ahmed Mohamed", "Manager", "Cairo", "Egypt", "01001234567", "0223456789");
        //Get supplier by id
        Supplier s = Supplier.getSupplierById(em, 210);
        if (s != null) {
            System.out.println("Supplier Found: " + s.getCompanyName());
        } else {
            System.out.println("Supplier not found");
        }
       //Update supplier
      // Supplier.updateSupplier(em, 210, "VHS", "Ahmed Hossam", "Sales Manager", "Alexandria", "Egypt", "01122334455", "033334455");
//       //Delete Supplier
       //Supplier.deleteSupplier(em, 210);
//       //Get all Suppliers          List<Supplier> allSuppliers = Supplier.getAllSuppliers(em);
//    for (Supplier ss : allSuppliers) {
//        System.out.println("Supplier: " + ss.getCompanyName() + " - " + ss.getContactName());
//    }
      
        //=======================================================================================
        // ✅ 1. Display all products and their suppliers
        List<Object[]> productsWithSuppliers = Operations.getProductsWithSuppliers(em);
        System.out.println("🔹 Products with their Suppliers:");
        for (Object[] result : productsWithSuppliers) {
            System.out.println("Product: " + result[0] + ", Supplier: " + result[1]);
        }
        // ✅ 2. Display all products supplied by suppliers located in a specific country (e.g., USA)
        List<Product> productsInCountry = Operations.getProductsBySupplierCountry(em, "USA");
             if (productsInCountry != null && !productsInCountry.isEmpty()) {
            for (Product product : productsInCountry) {
                System.out.println("Product Name: " + product.getProductName());
                System.out.println("Unit Price: " + product.getUnitPrice());
                System.out.println("Supplier: " + product.getSupplierId().getCompanyName());
                System.out.println("--------------------------");
            }
        } else {
            System.out.println("No products found for suppliers in " + "USA");}
        // ✅ 3. Display suppliers who supply a specific product
        List<Supplier> suppliers = Operations.getSuppliersByProductName(em, "Laptop");
        System.out.println("🔹 Suppliers for product 'Laptop':");
        for (Supplier ss : suppliers) {
            System.out.println(ss.getCompanyName());
        }
            System.out.println("---------------------");
         // ✅ 4. Retrieves product names that are supplied by the company "PhoneWorld"
        List<Object[]> results = Operations.getProductsAndSuppliersBySearch(em, "PhoneWorld");
        if (results != null && !results.isEmpty()) {
            for (Object[] result : results) {
                String productName = (String) result[0];
                String companyName = (String) result[1];
                System.out.println("Product Name: " + productName);
                System.out.println("Supplier Company: " + companyName);
                System.out.println("--------------------------");
            }
        } else {
            System.out.println("No products or suppliers found for the search term: " + "PhoneWorld");
        } 

        // ✅ 5. Number of products supplied by each supplier
        List<Object[]> countPerSupplier = Operations.countProductsPerSupplier(em);
        System.out.println("🔹 Count of Products per Supplier:");
        for (Object[] row : countPerSupplier) {
            System.out.println("Supplier: " + row[0] + ", Product Count: " + row[1]);
        }

        // 6.✅ Updates the contact name of a supplier based on the old name.
        Operations.updateSupplierNameByOldName(em, "Shahd Saed", "Mona Ali");

        //7. ✅ Deletes all order items that belong to an order with the specified order number.
        Operations.deleteOrderItemsByOrderNumber(em, "ORD006");
        //8. ✅ Retrieves customers and the products they have ordered using LEFT JOINs to include customers with no orders.
        Operations.getCustomerAndOrderedProducts(em);
        //9. ✅ Retrieves customers along with the total amount they have spent on their orders.
        Operations.getCustomerAndTotalOrderAmount(em);
        }
         catch (Exception e) {
            // Handle errors by rolling back the transaction if necessary
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            e.printStackTrace();
        } finally {
            
            // Step 8: Close EntityManager and EntityManagerFactory
            em.close();
            emf.close();
        }
    }
}
