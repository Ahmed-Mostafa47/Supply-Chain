 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.supplychainn;

import java.awt.BorderLayout;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author HP
 */

public class CustomerGUI extends javax.swing.JFrame {

    private JTable table;
    private DefaultTableModel model;
    private JButton addButton, updateButton, deleteButton;
    private JPanel panel;

    EntityManagerFactory emf = Persistence.createEntityManagerFactory("com.mycompany_SupplyChainn_jar_1.0-SNAPSHOTPU");
    EntityManager em = emf.createEntityManager();

    public CustomerGUI() {
        setTitle("Customer Management");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panel = new JPanel();
        panel.setLayout(new BorderLayout());

        // Table Setup
        model = new DefaultTableModel();
        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane, BorderLayout.CENTER);

        // Columns
        model.addColumn("Customer ID");
        model.addColumn("First Name");
        model.addColumn("Last Name");
        model.addColumn("Phone");

        // Buttons
        JPanel buttonPanel = new JPanel();
        addButton = new JButton("Add Customer");
        updateButton = new JButton("Update Customer");
        deleteButton = new JButton("Delete Customer");

        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        add(panel);
        loadCustomers();

        addButton.addActionListener(e -> addCustomer());
        updateButton.addActionListener(e -> updateCustomer());
        deleteButton.addActionListener(e -> deleteCustomer());
    }

    private void loadCustomers() {
        List<Customer> customers = Customer.getAllCustomers(em);
        model.setRowCount(0);  // Clear table
        for (Customer customer : customers) {
            model.addRow(new Object[]{
                customer.getId(),
                customer.getFirstName(),
                customer.getLastName(),
                customer.getPhone()
            });
        }
    }

    // ✅ New Method: Get Next ID Automatically
    private int getNextCustomerId() {
        List<Customer> customers = Customer.getAllCustomers(em);
        int maxId = 0;
        for (Customer c : customers) {
            if (c.getId() > maxId) {
                maxId = c.getId();
            }
        }
        return maxId + 1;
    }

    private void addCustomer() {
        while (true) {
            try {
                int id = getNextCustomerId();  // Generate ID automatically

                String firstName = JOptionPane.showInputDialog(this, "Enter First Name");
                if (firstName == null) break;
                String lastName = JOptionPane.showInputDialog(this, "Enter Last Name");
                if (lastName == null) break;
                String country = JOptionPane.showInputDialog(this, "Enter Country");
                if (country == null) break;
                String city = JOptionPane.showInputDialog(this, "Enter City");
                if (city == null) break;
                String phone = JOptionPane.showInputDialog(this, "Enter Phone");
                if (phone == null) break;

                Customer.createCustomer(em, firstName, lastName, country, city, phone);
                JOptionPane.showMessageDialog(this, "Customer added successfully!");
                loadCustomers();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        }
    }

    private void updateCustomer() {
        while (true) {
            int row = table.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(this, "Please select a customer to update.");
                break;
            }
            int customerId = (int) model.getValueAt(row, 0);
            String newFirstName = JOptionPane.showInputDialog(this, "Enter new First Name:");
            if (newFirstName == null) break;
            String newLastName = JOptionPane.showInputDialog(this, "Enter new Last Name:");
            if (newLastName == null) break;
            String newCity = JOptionPane.showInputDialog(this, "Enter new City:");
            if (newCity == null) break;
            String newCountry = JOptionPane.showInputDialog(this, "Enter new Country:");
            if (newCountry == null) break;
            String newPhone = JOptionPane.showInputDialog(this, "Enter new Phone:");
            if (newPhone == null) break;

            Customer.updateCustomer(em, customerId, newFirstName, newLastName, newCity, newCountry, newPhone);
            JOptionPane.showMessageDialog(this, "Customer updated successfully!");
            loadCustomers();
        }
    }

    private void deleteCustomer() {
        int row = table.getSelectedRow();
        if (row != -1) {
            int customerId = (int) model.getValueAt(row, 0);
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete customer " + customerId + "?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                Customer.deleteCustomer(em, customerId);
                JOptionPane.showMessageDialog(this, "Customer deleted successfully.");
                loadCustomers();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a customer to delete.");
        }
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
       public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new CustomerGUI().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables


}