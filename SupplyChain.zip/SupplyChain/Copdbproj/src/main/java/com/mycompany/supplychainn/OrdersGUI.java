/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.supplychainn;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.math.BigDecimal;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author HP
 */
public class OrdersGUI extends JFrame {

    private JTextField idField, dateField, numberField, totalAmountField, customerIdField;
    private JTable table;
    private DefaultTableModel tableModel;
    private EntityManager em;

    public OrdersGUI() {
        em = Persistence.createEntityManagerFactory("com.mycompany_SupplyChainn_jar_1.0-SNAPSHOTPU").createEntityManager();
        setTitle("Orders Management");
        setSize(850, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Center the window
        setLayout(new BorderLayout(10, 10));

        // ==== Input Panel ====
        JPanel inputPanel = new JPanel(new GridLayout(5, 2, 10, 10));
        inputPanel.setBorder(BorderFactory.createTitledBorder("Order Details"));

        inputPanel.add(new JLabel("ID:"));
        idField = new JTextField();
        inputPanel.add(idField);

        inputPanel.add(new JLabel("Order Date:"));
        dateField = new JTextField();
        inputPanel.add(dateField);

        inputPanel.add(new JLabel("Order Number:"));
        numberField = new JTextField();
        inputPanel.add(numberField);

        inputPanel.add(new JLabel("Total Amount:"));
        totalAmountField = new JTextField();
        inputPanel.add(totalAmountField);

        inputPanel.add(new JLabel("Customer ID:"));
        customerIdField = new JTextField();
        inputPanel.add(customerIdField);

        add(inputPanel, BorderLayout.NORTH);

        // ==== Button Panel ====
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));

        JButton addButton = new JButton("Add Order");
        JButton updateButton = new JButton("Update Order");
        JButton deleteButton = new JButton("Delete Order");
        JButton viewButton = new JButton("View All");

        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(viewButton);

        add(buttonPanel, BorderLayout.SOUTH);

        // ==== Table ====
        tableModel = new DefaultTableModel(new Object[]{"ID", "Date", "Number", "Total", "CustomerID"}, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // ==== Events ====
        addButton.addActionListener(e -> {
            try {
                addOrder();
                JOptionPane.showMessageDialog(this, "Order added successfully.");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error adding order: " + ex.getMessage());
            }
        });

        updateButton.addActionListener(e -> {
            try {
                updateOrder();
                JOptionPane.showMessageDialog(this, "Order updated successfully.");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error updating order: " + ex.getMessage());
            }
        });

        deleteButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this order?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    int orderId = Integer.parseInt(table.getValueAt(selectedRow, 0).toString());
                    Orders.deleteOrder(em, orderId);
                    loadOrders();
                    JOptionPane.showMessageDialog(this, "Order deleted successfully.");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Please select an order to delete.");
            }
        });

        viewButton.addActionListener(e -> loadOrders());
    }

    private void addOrder() {
        int id = Integer.parseInt(idField.getText());
        String date = dateField.getText();
        String number = numberField.getText();
        BigDecimal total = new BigDecimal(totalAmountField.getText());
        int customerId = Integer.parseInt(customerIdField.getText());
        Orders.createOrder(em, id, date, number, total, customerId);
        loadOrders();
    }

    private void updateOrder() {
        int id = Integer.parseInt(idField.getText());
        String date = dateField.getText();
        String number = numberField.getText();
        BigDecimal total = new BigDecimal(totalAmountField.getText());
        int customerId = Integer.parseInt(customerIdField.getText());
        Orders.updateOrder(em, id, date, number, total, customerId);
        loadOrders();
    }

    private void loadOrders() {
        tableModel.setRowCount(0);
        List<Orders> ordersList = Orders.getAllOrders(em);
        for (Orders o : ordersList) {
            tableModel.addRow(new Object[]{
                o.getId(),
                o.getOrderDate(),
                o.getOrderNumber(),
                o.getTotalAmount(),
                o.getCustomerId().getId()
            });
        }
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
  public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new OrdersGUI().setVisible(true));
    }
}
    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables

