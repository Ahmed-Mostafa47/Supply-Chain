/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.supplychainn;

import java.math.BigDecimal;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import java.util.List;
import javax.persistence.Query;

public class Operations {

    // 1. Get all products with their supplier name
    public static List<Object[]> getProductsWithSuppliers(EntityManager em) {
        String jpql = "SELECT p.productName, s.contactName " +
                      "FROM Product p JOIN p.supplierId s";
        TypedQuery<Object[]> query = em.createQuery(jpql, Object[].class);
        return query.getResultList();
    }

    // 2. Get products by supplier's country
    public static List<Product> getProductsBySupplierCountry(EntityManager em, String country) {
        String queryStr = "SELECT p FROM Product p JOIN p.supplierId s WHERE s.country = :country";
        TypedQuery<Product> query = em.createQuery(queryStr, Product.class);
        query.setParameter("country", country);
        return query.getResultList();
    }

    // 3. Get all suppliers who supply a product with specific name
    public static List<Supplier> getSuppliersByProductName(EntityManager em, String productName) {
        String jpql = "SELECT DISTINCT s FROM Supplier s " +
                      "JOIN s.productCollection p " +
                      "WHERE p.productName = :productName";
        TypedQuery<Supplier> query = em.createQuery(jpql, Supplier.class);
        query.setParameter("productName", productName);
        return query.getResultList();
    }
    // ✅ 4. Retrieves product names that are supplied by a specfic company 
   public static List<Object[]> getProductsAndSuppliersBySearch(EntityManager em, String searchString) {
        String queryStr = "SELECT p.productName, s.companyName " +
                          "FROM Product p JOIN p.supplierId s " +
                          "WHERE p.productName LIKE :searchString OR s.companyName LIKE :searchString";
        Query query = em.createQuery(queryStr);
        query.setParameter("searchString", "%" + searchString + "%");
        return query.getResultList();
    }


    // 5. Count products per supplier
    public static List<Object[]> countProductsPerSupplier(EntityManager em) {
        String jpql = "SELECT s.companyName, COUNT(p) FROM Supplier s " +
                      "JOIN s.productCollection p GROUP BY s.companyName";
        TypedQuery<Object[]> query = em.createQuery(jpql, Object[].class);
        return query.getResultList();
    }
    
    // 6.✅ Updates the contact name of a supplier based on the old name.
    public static void updateSupplierNameByOldName(EntityManager em, String oldName, String newName) {
        em.getTransaction().begin();
        String jpql = "UPDATE Supplier s SET s.contactName = :newName WHERE s.contactName = :oldName";
        int updated = em.createQuery(jpql)
                        .setParameter("newName", newName)
                        .setParameter("oldName", oldName)
                        .executeUpdate();
        em.getTransaction().commit();
        System.out.println("Updated " + updated + " supplier(s).");
    }
    //7. ✅ Deletes all order items that belong to an order with the specified order number.
    public static void deleteOrderItemsByOrderNumber(EntityManager em, String orderNumber) {
        em.getTransaction().begin();
        String jpql = "DELETE FROM Orderitem oi WHERE oi.orderId.orderNumber = :orderNumber";
        int deleted = em.createQuery(jpql)
                        .setParameter("orderNumber", orderNumber)
                        .executeUpdate();
        em.getTransaction().commit();
        System.out.println("Deleted " + deleted + " order item(s).");
    }
    //8. ✅ Retrieves customers and the products they have ordered using LEFT JOINs to include customers with no orders.
    public static void getCustomerAndOrderedProducts(EntityManager em) {
        em.getTransaction().begin();
    String jpql = "SELECT c.firstName, c.lastName, p.productName " +
                  "FROM Customer c " +
                  "LEFT JOIN c.ordersCollection o " +
                  "LEFT JOIN o.orderitemCollection oi " +
                  "LEFT JOIN oi.productId p";
        List<Object[]> results = em.createQuery(jpql).getResultList();
        for (Object[] result : results) {
        String firstName = (String) result[0];
        String lastName = (String) result[1];
        String productName = (String) result[2];
        if (productName != null) {
            System.out.println("Customer: " + firstName + " " + lastName + " ordered " + productName);
        } else {
            System.out.println("Customer: " + firstName + " " + lastName + " has no orders.");
        }
    }
    
    em.getTransaction().commit();
}

//9. ✅ Retrieves customers along with the total amount they have spent on their orders.
    public static void getCustomerAndTotalOrderAmount(EntityManager em) {
        em.getTransaction().begin();

        String jpql = "SELECT c.firstName, c.lastName, SUM(oi.unitPrice * oi.quantity) " +
                      "FROM Customer c " +
                      "LEFT JOIN c.ordersCollection o " +
                      "LEFT JOIN o.orderitemCollection oi " +
                      "GROUP BY c.id";

        List<Object[]> results = em.createQuery(jpql).getResultList();

        for (Object[] result : results) {
            String firstName = (String) result[0];
            String lastName = (String) result[1];
            BigDecimal totalAmount = (BigDecimal) result[2]; 

            if (totalAmount != null && totalAmount.compareTo(BigDecimal.ZERO) > 0) {
                System.out.println("Customer: " + firstName + " " + lastName + " has spent " + totalAmount + " in total.");
            }
        }

        em.getTransaction().commit();
    }

    }



