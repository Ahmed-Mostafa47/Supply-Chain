/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.supplychainn;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "orderitem")
@NamedQueries({
    @NamedQuery(name = "Orderitem.findAll", query = "SELECT o FROM Orderitem o"),
    @NamedQuery(name = "Orderitem.findById", query = "SELECT o FROM Orderitem o WHERE o.id = :id"),
    @NamedQuery(name = "Orderitem.findByUnitPrice", query = "SELECT o FROM Orderitem o WHERE o.unitPrice = :unitPrice"),
    @NamedQuery(name = "Orderitem.findByQuantity", query = "SELECT o FROM Orderitem o WHERE o.quantity = :quantity")})
public class Orderitem implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "Id")
    private Integer id;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Basic(optional = false)
    @Column(name = "UnitPrice")
    private BigDecimal unitPrice;
    @Basic(optional = false)
    @Column(name = "Quantity")
    private int quantity;
    @JoinColumn(name = "ProductId", referencedColumnName = "Id")
    @ManyToOne(optional = false)
    private Product productId;
    @JoinColumn(name = "OrderId", referencedColumnName = "Id")
    @ManyToOne(optional = false)
    private Orders orderId;

    public Orderitem() {
    }

    public Orderitem(Integer id) {
        this.id = id;
    }

    public Orderitem(Integer id, BigDecimal unitPrice, int quantity) {
        this.id = id;
        this.unitPrice = unitPrice;
        this.quantity = quantity;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public BigDecimal getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(BigDecimal unitPrice) {
        this.unitPrice = unitPrice;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public Product getProductId() {
        return productId;
    }

    public void setProductId(Product productId) {
        this.productId = productId;
    }

    public Orders getOrderId() {
        return orderId;
    }

    public void setOrderId(Orders orderId) {
        this.orderId = orderId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Orderitem)) {
            return false;
        }
        Orderitem other = (Orderitem) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.supplychainn.Orderitem[ id=" + id + " ]";
    }
     // Create
    public static void createOrderItem(EntityManager em, Integer id, BigDecimal unitPrice, int quantity, int productid, int orderid) {
        em.getTransaction().begin();
        Orderitem orderItem = new Orderitem();
        orderItem.setId(id);
        orderItem.setUnitPrice(unitPrice);
        orderItem.setQuantity(quantity);
        Product product = em.find(Product.class, productid); 
        orderItem.setProductId(product);
        Orders order=em.find(Orders.class,orderid);
        orderItem.setOrderId(order);
        em.persist(orderItem);
        em.getTransaction().commit();
        System.out.println("Order item with "+id+ "created successfully.");
    }

    // Read by ID
    public static Orderitem getOrderItemById(EntityManager em, int itemId) {
        return em.find(Orderitem.class, itemId);
    }

    // Update
    public static void updateOrderItem(EntityManager em, int itemId, BigDecimal newUnitPrice, int newQuantity, int newProduct, int newOrder) {
        em.getTransaction().begin();
        Orderitem item = em.find(Orderitem.class, itemId);
        if (item != null) {
            item.setUnitPrice(newUnitPrice);
            item.setQuantity(newQuantity);
            Product Product = em.find(Product.class, newProduct); 
            item.setProductId(Product);
            Orders order=em.find(Orders.class,newOrder);
            item.setOrderId(order);
            em.merge(item);
            System.out.println("Order item with "+itemId+" updated successfully.");
        } else {
            System.out.println("Order item not found with ID: " + itemId);
        }
        em.getTransaction().commit();
    }

    // Delete
    public static void deleteOrderItem(EntityManager em, int itemId) {
        em.getTransaction().begin();
        Orderitem item = em.find(Orderitem.class, itemId);
        if (item != null) {
            em.remove(item);
            System.out.println("Order item with "+itemId+" deleted successfully.");
        } else {
            System.out.println("Order item not found with ID: " + itemId);
        }
        em.getTransaction().commit();
    }

    // Get All Order Items
    public static List<Orderitem> getAllOrderItems(EntityManager em) {
        return em.createQuery("SELECT oi FROM Orderitem oi", Orderitem.class).getResultList();
    }
}
