/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.supplychainn;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "supplier")
@NamedQueries({
    @NamedQuery(name = "Supplier.findAll", query = "SELECT s FROM Supplier s"),
    @NamedQuery(name = "Supplier.findById", query = "SELECT s FROM Supplier s WHERE s.id = :id"),
    @NamedQuery(name = "Supplier.findByCompanyName", query = "SELECT s FROM Supplier s WHERE s.companyName = :companyName"),
    @NamedQuery(name = "Supplier.findByContactName", query = "SELECT s FROM Supplier s WHERE s.contactName = :contactName"),
    @NamedQuery(name = "Supplier.findByContactTitle", query = "SELECT s FROM Supplier s WHERE s.contactTitle = :contactTitle"),
    @NamedQuery(name = "Supplier.findByCity", query = "SELECT s FROM Supplier s WHERE s.city = :city"),
    @NamedQuery(name = "Supplier.findByCountry", query = "SELECT s FROM Supplier s WHERE s.country = :country"),
    @NamedQuery(name = "Supplier.findByPhone", query = "SELECT s FROM Supplier s WHERE s.phone = :phone"),
    @NamedQuery(name = "Supplier.findByFax", query = "SELECT s FROM Supplier s WHERE s.fax = :fax")})
public class Supplier implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "Id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "CompanyName")
    private String companyName;
    @Column(name = "ContactName")
    private String contactName;
    @Column(name = "ContactTitle")
    private String contactTitle;
    @Column(name = "City")
    private String city;
    @Column(name = "Country")
    private String country;
    @Column(name = "Phone")
    private String phone;
    @Column(name = "Fax")
    private String fax;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "supplierId")
    private Collection<Product> productCollection;

    public Supplier() {
    }

    public Supplier(Integer id) {
        this.id = id;
    }

    public Supplier(Integer id, String companyName) {
        this.id = id;
        this.companyName = companyName;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getContactTitle() {
        return contactTitle;
    }

    public void setContactTitle(String contactTitle) {
        this.contactTitle = contactTitle;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public Collection<Product> getProductCollection() {
        return productCollection;
    }

    public void setProductCollection(Collection<Product> productCollection) {
        this.productCollection = productCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Supplier)) {
            return false;
        }
        Supplier other = (Supplier) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.supplychainn.Supplier[ id=" + id + " ]";
    }
    // Create
    public static void createSupplier(EntityManager em, int id, String companyName, String contactName, String contactTitle,
                                      String city, String country, String phone, String fax) {
        em.getTransaction().begin();
        Supplier supplier = new Supplier();
        supplier.setId(id);
        supplier.setCompanyName(companyName);
        supplier.setContactName(contactName);
        supplier.setContactTitle(contactTitle);
        supplier.setCity(city);
        supplier.setCountry(country);
        supplier.setPhone(phone);
        supplier.setFax(fax);
        em.persist(supplier);
        em.getTransaction().commit();
        System.out.println("Supplier with id "+id+" created successfully.");
    }

    // Read by ID
    public static Supplier getSupplierById(EntityManager em, int supplierId) {
        return em.find(Supplier.class, supplierId);
    }

    // Update
    public static void updateSupplier(EntityManager em, int id, String companyName, String contactName, String contactTitle,
                                      String city, String country, String phone, String fax) {
        em.getTransaction().begin();
        Supplier supplier = em.find(Supplier.class, id);
        if (supplier != null) {
            supplier.setCompanyName(companyName);
            supplier.setContactName(contactName);
            supplier.setContactTitle(contactTitle);
            supplier.setCity(city);
            supplier.setCountry(country);
            supplier.setPhone(phone);
            supplier.setFax(fax);
            em.merge(supplier);
            System.out.println("Supplier with "+id+" updated successfully.");
        } else {
            System.out.println("Supplier not found with ID: " + id);
        }
        em.getTransaction().commit();
    }

    // Delete
    public static void deleteSupplier(EntityManager em, int id) {
        em.getTransaction().begin();
        Supplier supplier = em.find(Supplier.class, id);
        if (supplier != null) {
            em.remove(supplier);
            System.out.println("Supplier" +id+" deleted successfully.");
        } else {
            System.out.println("Supplier not found with ID: " + id);
        }
        em.getTransaction().commit();
    }

    // Get All 
    public static List<Supplier> getAllSuppliers(EntityManager em) {
        return em.createQuery("SELECT s FROM Supplier s", Supplier.class).getResultList();
    }
}
