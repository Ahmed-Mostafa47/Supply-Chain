/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.supplychainn;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "orders")
@NamedQueries({
    @NamedQuery(name = "Orders.findAll", query = "SELECT o FROM Orders o"),
    @NamedQuery(name = "Orders.findById", query = "SELECT o FROM Orders o WHERE o.id = :id"),
    @NamedQuery(name = "Orders.findByOrderDate", query = "SELECT o FROM Orders o WHERE o.orderDate = :orderDate"),
    @NamedQuery(name = "Orders.findByOrderNumber", query = "SELECT o FROM Orders o WHERE o.orderNumber = :orderNumber"),
    @NamedQuery(name = "Orders.findByTotalAmount", query = "SELECT o FROM Orders o WHERE o.totalAmount = :totalAmount")})
public class Orders implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "Id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "OrderDate")
    private String orderDate;
    @Column(name = "OrderNumber")
    private String orderNumber;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "TotalAmount")
    private BigDecimal totalAmount;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "orderId")
    private Collection<Orderitem> orderitemCollection;
    @JoinColumn(name = "CustomerId", referencedColumnName = "Id")
    @ManyToOne(optional = false)
    private Customer customerId;

    public Orders() {
    }

    public Orders(Integer id) {
        this.id = id;
    }

    public Orders(Integer id, String orderDate) {
        this.id = id;
        this.orderDate = orderDate;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public Collection<Orderitem> getOrderitemCollection() {
        return orderitemCollection;
    }

    public void setOrderitemCollection(Collection<Orderitem> orderitemCollection) {
        this.orderitemCollection = orderitemCollection;
    }

    public Customer getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Customer customerId) {
        this.customerId = customerId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Orders)) {
            return false;
        }
        Orders other = (Orders) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.supplychainn.Orders[ id=" + id + " ]";
    }

    // ---------------------- CRUD Operations ----------------------

    // Create
   public static void createOrder(EntityManager em, Integer id, String orderDate, String orderNumber, BigDecimal totalAmount, int customerid) {
    em.getTransaction().begin();
    Orders order = new Orders();
    order.setId(id);
    order.setOrderDate(orderDate);
    order.setOrderNumber(orderNumber);
    order.setTotalAmount(totalAmount);
        Customer customer = em.find(Customer.class, customerid);
    
    if (customer != null) {
        order.setCustomerId(customer);  
        em.persist(order);  
        em.getTransaction().commit();
        System.out.println(orderNumber+" created successfully.");
    } else {
        System.out.println("Customer with ID " + customerid + " not found.");
        em.getTransaction().rollback(); 
    }
}


    // Read by ID
    public static Orders getOrderById(EntityManager em, int orderId) {
        return em.find(Orders.class, orderId);
    }

    // Update
    public static void updateOrder(EntityManager em, int orderId, String newOrderDate, String newOrderNumber,
            BigDecimal newTotalAmount, int customerid) {
        em.getTransaction().begin();
        Orders order = em.find(Orders.class, orderId);
        if (order != null) {
            order.setOrderDate(newOrderDate);
            order.setOrderNumber(newOrderNumber);
            order.setTotalAmount(newTotalAmount);
            Customer customer=Customer.getCustomerById(em, customerid);
            order.setCustomerId(customer);
            em.merge(order);
            System.out.println("Order with id "+orderId+" updated successfully.");
        } else {
            System.out.println("Order not found with ID: " + orderId);
        }
        em.getTransaction().commit();
    }

    // Delete
    public static void deleteOrder(EntityManager em, int orderId) {
        em.getTransaction().begin();
        Orders order = em.find(Orders.class, orderId);
        if (order != null) {
            em.remove(order);
            System.out.println("Order with id "+orderId+"deleted successfully.");
        } else {
            System.out.println("Order not found with ID: " + orderId);
        }
        em.getTransaction().commit();
    }

    // Get All Orders
    public static List<Orders> getAllOrders(EntityManager em) {
        return em.createQuery("SELECT o FROM Orders o", Orders.class).getResultList();
    }

}
