/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.supplychainn;

/**
 *
 * @author HP
 */
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.event.ListSelectionListener;
import java.util.List;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.DefaultTableModel;


public class SupplierGUI extends JFrame {
    private EntityManagerFactory emf;
    private EntityManager em;
    private JTextField idField, companyNameField, contactNameField, contactTitleField,
            cityField, countryField, phoneField, faxField;
    private JTable supplierTable;
    private DefaultTableModel tableModel;
    private JButton addButton, updateButton, deleteButton, getByIdButton, getAllButton;

    public SupplierGUI() {
        emf = Persistence.createEntityManagerFactory("com.mycompany_SupplyChainn_jar_1.0-SNAPSHOTPU");
        em = emf.createEntityManager();

        setTitle("Supplier Management");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        // ========== الحقول ==========
        JLabel idLabel = new JLabel("ID:");
        idLabel.setBounds(20, 20, 80, 25);
        add(idLabel);
        idField = new JTextField();
        idField.setBounds(100, 20, 150, 25);
        add(idField);

        JLabel companyNameLabel = new JLabel("Company Name:");
        companyNameLabel.setBounds(20, 50, 100, 25);
        add(companyNameLabel);
        companyNameField = new JTextField();
        companyNameField.setBounds(130, 50, 150, 25);
        add(companyNameField);

        JLabel contactNameLabel = new JLabel("Contact Name:");
        contactNameLabel.setBounds(20, 80, 100, 25);
        add(contactNameLabel);
        contactNameField = new JTextField();
        contactNameField.setBounds(130, 80, 150, 25);
        add(contactNameField);

        JLabel contactTitleLabel = new JLabel("Contact Title:");
        contactTitleLabel.setBounds(20, 110, 100, 25);
        add(contactTitleLabel);
        contactTitleField = new JTextField();
        contactTitleField.setBounds(130, 110, 150, 25);
        add(contactTitleField);

        JLabel cityLabel = new JLabel("City:");
        cityLabel.setBounds(20, 140, 80, 25);
        add(cityLabel);
        cityField = new JTextField();
        cityField.setBounds(100, 140, 150, 25);
        add(cityField);

        JLabel countryLabel = new JLabel("Country:");
        countryLabel.setBounds(20, 170, 80, 25);
        add(countryLabel);
        countryField = new JTextField();
        countryField.setBounds(100, 170, 150, 25);
        add(countryField);

        JLabel phoneLabel = new JLabel("Phone:");
        phoneLabel.setBounds(20, 200, 80, 25);
        add(phoneLabel);
        phoneField = new JTextField();
        phoneField.setBounds(100, 200, 150, 25);
        add(phoneField);

        JLabel faxLabel = new JLabel("Fax:");
        faxLabel.setBounds(20, 230, 80, 25);
        add(faxLabel);
        faxField = new JTextField();
        faxField.setBounds(100, 230, 150, 25);
        add(faxField);

        // ========== الأزرار ==========
        addButton = new JButton("Add");
        addButton.setBounds(300, 20, 100, 30);
        add(addButton);

        updateButton = new JButton("Update");
        updateButton.setBounds(300, 60, 100, 30);
        add(updateButton);

        deleteButton = new JButton("Delete");
        deleteButton.setBounds(300, 100, 100, 30);
        add(deleteButton);

        getByIdButton = new JButton("Get By ID");
        getByIdButton.setBounds(300, 140, 100, 30);
        add(getByIdButton);

        getAllButton = new JButton("Get All");
        getAllButton.setBounds(300, 180, 100, 30);
        add(getAllButton);

        // ========== جدول العرض ==========
        String[] columnNames = {"ID", "Company Name", "Contact Name", "City", "Country", "Phone", "Fax"};
        tableModel = new DefaultTableModel(columnNames, 0);
        supplierTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(supplierTable);
        scrollPane.setBounds(20, 270, 550, 160);
        add(scrollPane);

        // لما يختار صف في الجدول
        supplierTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                int selectedRow = supplierTable.getSelectedRow();
                if (selectedRow != -1) {
                    idField.setText(supplierTable.getValueAt(selectedRow, 0).toString());
                }
            }
        });

        // ========== الأحداث ==========
        addButton.addActionListener(e -> addSupplier());
        updateButton.addActionListener(e -> updateSupplier());
        deleteButton.addActionListener(e -> deleteSupplier());
        getByIdButton.addActionListener(e -> getSupplierById());
        getAllButton.addActionListener(e -> getAllSuppliers());

        setVisible(true);
    }

    private void addSupplier() {
        try {
            Supplier.createSupplier(em,
                    Integer.parseInt(idField.getText()),
                    companyNameField.getText(),
                    contactNameField.getText(),
                    contactTitleField.getText(),
                    cityField.getText(),
                    countryField.getText(),
                    phoneField.getText(),
                    faxField.getText()
            );
            JOptionPane.showMessageDialog(this, "✅ Supplier added.");
            getAllSuppliers(); // تحديث الجدول
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "❌ Error: " + e.getMessage());
        }
    }

    private void updateSupplier() {
        try {
            Supplier.updateSupplier(em,
                    Integer.parseInt(idField.getText()),
                    companyNameField.getText(),
                    contactNameField.getText(),
                    contactTitleField.getText(),
                    cityField.getText(),
                    countryField.getText(),
                    phoneField.getText(),
                    faxField.getText()
            );
            JOptionPane.showMessageDialog(this, "✅ Supplier updated.");
            getAllSuppliers();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "❌ Error: " + e.getMessage());
        }
    }

    private void deleteSupplier() {
        try {
            int selectedRow = supplierTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "❗ Please select a supplier to delete.");
                return;
            }

            int id = (int) supplierTable.getValueAt(selectedRow, 0);
            Supplier.deleteSupplier(em, id);
            tableModel.removeRow(selectedRow); // احذف من الجدول
            JOptionPane.showMessageDialog(this, "✅ Supplier deleted.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "❌ Error: " + e.getMessage());
        }
    }

   private void getSupplierById() {
    try {
        // Retrieve the supplier based on the ID entered in the text field
        Supplier supplier = Supplier.getSupplierById(em, Integer.parseInt(idField.getText()));

        if (supplier != null) {
            // Clear the previous data in the table
            tableModel.setRowCount(0);

            // Add the supplier's information as a new row in the table
            Object[] row = {
                supplier.getId(),
                supplier.getCompanyName(),
                supplier.getContactName(),
                supplier.getCity(),
                supplier.getCountry(),
                supplier.getPhone(),
                supplier.getFax()
            };
            tableModel.addRow(row);

            // Optionally, show a success message
            JOptionPane.showMessageDialog(this, "✅ Supplier information loaded into the table.");
        } else {
            // Clear the table if the supplier is not found
            tableModel.setRowCount(0);
            JOptionPane.showMessageDialog(this, "⚠️ Supplier not found.");
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "❌ Error: " + e.getMessage());
    }
}

    private void getAllSuppliers() {
        try {
            List<Supplier> list = Supplier.getAllSuppliers(em);
            tableModel.setRowCount(0); // clear old data
            for (Supplier s : list) {
                Object[] row = {
                    s.getId(),
                    s.getCompanyName(),
                    s.getContactName(),
                    s.getCity(),
                    s.getCountry(),
                    s.getPhone(),
                    s.getFax()
                };
                tableModel.addRow(row);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "❌ Error loading suppliers: " + e.getMessage());
        }
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SupplierGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SupplierGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SupplierGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SupplierGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SupplierGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
