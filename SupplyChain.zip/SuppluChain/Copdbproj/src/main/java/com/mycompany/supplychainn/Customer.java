/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.supplychainn;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 *
 * @author HP
 */
@Entity
@Table(name = "customer")
@NamedQueries({
    @NamedQuery(name = "Customer.findAll", query = "SELECT c FROM Customer c"),
    @NamedQuery(name = "Customer.findById", query = "SELECT c FROM Customer c WHERE c.id = :id"),
    @NamedQuery(name = "Customer.findByFirstName", query = "SELECT c FROM Customer c WHERE c.firstName = :firstName"),
    @NamedQuery(name = "Customer.findByLastName", query = "SELECT c FROM Customer c WHERE c.lastName = :lastName"),
    @NamedQuery(name = "Customer.findByCity", query = "SELECT c FROM Customer c WHERE c.city = :city"),
    @NamedQuery(name = "Customer.findByCountry", query = "SELECT c FROM Customer c WHERE c.country = :country"),
    @NamedQuery(name = "Customer.findByPhone", query = "SELECT c FROM Customer c WHERE c.phone = :phone")})
public class Customer implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "Id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "FirstName")
    private String firstName;
    @Basic(optional = false)
    @Column(name = "LastName")
    private String lastName;
    @Column(name = "City")
    private String city;
    @Column(name = "Country")
    private String country;
    @Column(name = "Phone")
    private String phone;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "customerId")
    private Collection<Orders> ordersCollection;

    public Customer() {
    }

    public Customer(Integer id) {
        this.id = id;
    }

    public Customer(Integer id, String firstName, String lastName) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    Customer(String firstName, String lastName, String phone) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Collection<Orders> getOrdersCollection() {
        return ordersCollection;
    }

    public void setOrdersCollection(Collection<Orders> ordersCollection) {
        this.ordersCollection = ordersCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Customer)) {
            return false;
        }
        Customer other = (Customer) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.mycompany.supplychainn.Customer[ id=" + id + " ]";
    }
    private  static int getNextCustomerId(EntityManager em) {
        List<Customer> customers = Customer.getAllCustomers(em);
        int maxId = 0;
        for (Customer c : customers) {
            if (c.getId() > maxId) {
                maxId = c.getId();
            }
        }
        return maxId + 1;
    }
    
     // Create
    public static void createCustomer(EntityManager em, String firstName, String lastName,String city, String country ,String Phone) {
        em.getTransaction().begin();
         Customer customer = new Customer();
        customer.setId(getNextCustomerId(em));  
        customer.setFirstName(firstName);
        customer.setLastName(lastName);
        customer.setCity(city);
        customer.setCountry(country);
        customer.setPhone(Phone);
        em.persist(customer);
        em.getTransaction().commit();
        System.out.println("Customer "+firstName+" created successfully.");
    }

    // Read by ID
    public static Customer getCustomerById(EntityManager em, int customerId) {
        return em.find(Customer.class, customerId);
    }

    // Update
    public static void updateCustomer(EntityManager em, int customerId, String newFirstName, String newLastName,
            String newCity, String newCountry, String newPhone) {
        em.getTransaction().begin();
        Customer customer = em.find(Customer.class, customerId);
        if (customer != null) {
            customer.setFirstName(newFirstName);
            customer.setLastName(newLastName);
            customer.setCity(newCity);
            customer.setCountry(newCountry);
            customer.setPhone(newPhone);
            em.merge(customer);
            System.out.println("Customer with id "+customerId+ " updated successfully.");
        } else {
            System.out.println("Customer not found with ID: " + customerId);
        }
        em.getTransaction().commit();
    }

    // Delete
    public static void deleteCustomer(EntityManager em, int customerId) {
        em.getTransaction().begin();
        Customer customer = em.find(Customer.class, customerId);
        if (customer != null) {
            em.remove(customer);
            System.out.println("Customer with id "+customerId+" deleted successfully.");
        } else {
            System.out.println("Customer not found with ID: " + customerId);
        }
        em.getTransaction().commit();
    }

    // Get all Customers
    public static List<Customer> getAllCustomers(EntityManager em) {
        return em.createQuery("SELECT c FROM Customer c", Customer.class).getResultList();
    }

    // ----------------------------------------------------------------------

}
