package com.mycompany.supplychainn;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.math.BigDecimal;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;


public class OrderItemGUI extends JFrame {
    private JTextField idField, unitPriceField, quantityField, productIdField, orderIdField;
    private JTable table;
    private DefaultTableModel tableModel;
    private EntityManager em;

    public OrderItemGUI() {
        em = Persistence.createEntityManagerFactory("com.mycompany_SupplyChainn_jar_1.0-SNAPSHOTPU").createEntityManager();
        setTitle("Order Items Management");
        setSize(800, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel(new GridLayout(6, 2));
        inputPanel.add(new JLabel("ID:"));
        idField = new JTextField();
        inputPanel.add(idField);
        inputPanel.add(new JLabel("Unit Price:"));
        unitPriceField = new JTextField();
        inputPanel.add(unitPriceField);
        inputPanel.add(new JLabel("Quantity:"));
        quantityField = new JTextField();
        inputPanel.add(quantityField);
        inputPanel.add(new JLabel("Product ID:"));
        productIdField = new JTextField();
        inputPanel.add(productIdField);
        inputPanel.add(new JLabel("Order ID:"));
        orderIdField = new JTextField();
        inputPanel.add(orderIdField);

        JButton addButton = new JButton("Add Item");
        JButton updateButton = new JButton("Update Item");
        JButton deleteButton = new JButton("Delete Item");
        JButton viewButton = new JButton("View All");
        inputPanel.add(addButton);
        inputPanel.add(updateButton);
        inputPanel.add(deleteButton);
        inputPanel.add(viewButton);

        add(inputPanel, BorderLayout.NORTH);

        tableModel = new DefaultTableModel(new Object[]{"ID", "Unit Price", "Quantity", "Product ID", "Order ID"}, 0);
        table = new JTable(tableModel);
        add(new JScrollPane(table), BorderLayout.CENTER);

        addButton.addActionListener(e -> {
            try {
                addItem();
                JOptionPane.showMessageDialog(this, "Order item added successfully.");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error adding item: " + ex.getMessage());
            }
        });

        updateButton.addActionListener(e -> {
            try {
                updateItem();
                JOptionPane.showMessageDialog(this, "Order item updated successfully.");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error updating item: " + ex.getMessage());
            }
        });

        deleteButton.addActionListener(e -> {
            int selectedRow = table.getSelectedRow();
            if (selectedRow != -1) {
                int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this item?", "Confirm", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    int itemId = Integer.parseInt(table.getValueAt(selectedRow, 0).toString());
                    Orderitem.deleteOrderItem(em, itemId);
                    loadItems();
                    JOptionPane.showMessageDialog(this, "Item deleted successfully.");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Please select an item to delete.");
            }
        });

        viewButton.addActionListener(e -> loadItems());
    }

    private void addItem() {
        int id = Integer.parseInt(idField.getText());
        BigDecimal unitPrice = new BigDecimal(unitPriceField.getText());
        int quantity = Integer.parseInt(quantityField.getText());
        int productId = Integer.parseInt(productIdField.getText());
        int orderId = Integer.parseInt(orderIdField.getText());

        Orderitem.createOrderItem(em, id, unitPrice, quantity, productId, orderId);
        loadItems();
    }

    private void updateItem() {
        int id = Integer.parseInt(idField.getText());
        BigDecimal unitPrice = new BigDecimal(unitPriceField.getText());
        int quantity = Integer.parseInt(quantityField.getText());
        int productId = Integer.parseInt(productIdField.getText());
        int orderId = Integer.parseInt(orderIdField.getText());

        Orderitem.updateOrderItem(em, id, unitPrice, quantity, productId, orderId);
        loadItems();
    }

    private void loadItems() {
        tableModel.setRowCount(0);
        List<Orderitem> itemList = Orderitem.getAllOrderItems(em);
        for (Orderitem oi : itemList) {
            tableModel.addRow(new Object[]{
                    oi.getId(),
                    oi.getUnitPrice(),
                    oi.getQuantity(),
                    oi.getProductId().getId(),
                    oi.getOrderId().getId()
            });
        }
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(OrderItemGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(OrderItemGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(OrderItemGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(OrderItemGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new OrderItemGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
