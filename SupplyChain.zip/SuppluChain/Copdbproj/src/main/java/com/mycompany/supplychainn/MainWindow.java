/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.supplychainn;

import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTabbedPane;

/**
 *
 * @author HP
 */
public class MainWindow extends JFrame {
    private JButton productsButton, suppliersButton, ordersButton, orderItemsButton, customersButton;

    public MainWindow() {
        setTitle("Main Menu");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        
         customersButton= new JButton("Customers");
        customersButton.setBounds(50, 50, 150, 30);
        add(customersButton);

        suppliersButton = new JButton("Suppliers");
        suppliersButton.setBounds(50, 100, 150, 30);
        add(suppliersButton);

        ordersButton = new JButton("Orders");
        ordersButton.setBounds(50, 150, 150, 30);
        add(ordersButton);

        orderItemsButton = new JButton("Order Items");
        orderItemsButton.setBounds(50, 200, 150, 30);
        add(orderItemsButton);

         productsButton= new JButton("Products");
        productsButton.setBounds(50, 250, 150, 30);
        add(productsButton);

        productsButton.addActionListener(e -> openProductsPage());
        suppliersButton.addActionListener(e -> openSuppliersPage());
        ordersButton.addActionListener(e -> openOrdersPage());
        orderItemsButton.addActionListener(e -> openOrderItemsPage());
        customersButton.addActionListener(e -> openCustomersPage());

        setVisible(true);
    }

    private void openProductsPage() {
        new ProductGUI().setVisible(true);
    }

    private void openSuppliersPage() {
        new SupplierGUI().setVisible(true);
    }

    private void openOrdersPage() {
        new OrdersGUI().setVisible(true);
    }

    private void openOrderItemsPage() {
        new OrderItemGUI().setVisible(true);
    }

    private void openCustomersPage() {
        new CustomerGUI().setVisible(true);
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainWindow().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
